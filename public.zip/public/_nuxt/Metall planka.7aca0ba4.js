import"./entry.946f4788.js";const a=""+globalThis.__publicAssetsURL("icons/Metall palasa.svg"),l=""+globalThis.__publicAssetsURL("icons/Metall planka.svg");export{a as _,l as a};
